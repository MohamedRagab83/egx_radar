"""Data merge and orchestration for multi-source OHLCV (Layer 2)."""

import logging
import math
import threading
import time
from typing import Dict, List, Optional, Tuple

import pandas as pd

from egx_radar.config.settings import K, SYMBOLS, DATA_SOURCE_CFG, _data_cfg_lock
from egx_radar.data.fetchers import (
    _fetch_yahoo,
    _fetch_stooq,
    _fetch_av_single,
    _fetch_investing,
    _fetch_twelve_data,
)

log = logging.getLogger(__name__)

_source_labels: Dict[str, str] = {}
_source_labels_lock = threading.Lock()


def _merge_ohlcv(
    sym: str,
    yahoo_df: Optional[pd.DataFrame],
    stooq_df: Optional[pd.DataFrame],
    av_df:    Optional[pd.DataFrame],
    inv_price: Optional[float],
    td_df:    Optional[pd.DataFrame] = None,
) -> Tuple[Optional[pd.DataFrame], str]:
    """
    Select best available OHLCV source with priority:
      Yahoo-available:  Yahoo > Stooq > TD > AV
      Yahoo-absent:     TD    > Stooq > AV
    Consensus close = trimmed mean of sources within 5% of each other.
    """
    yahoo_ok = yahoo_df is not None and len(yahoo_df) >= K.MIN_BARS

    for df_, label in [(yahoo_df, "Yahoo"), (stooq_df, "Stooq"), (av_df, "AV"), (td_df, "TD")]:
        if df_ is not None:
            if "Volume" not in df_.columns:
                df_.loc[:, "Volume"] = 0.0

    candidates: List[Tuple[pd.DataFrame, str]] = []
    for df_, lbl in [(yahoo_df, "Yahoo"), (stooq_df, "Stooq"), (av_df, "AV"), (td_df, "TD")]:
        if df_ is None or "Close" not in df_.columns:
            continue
        thresh = K.MIN_BARS if lbl == "Yahoo" else K.MIN_BARS_RELAXED
        if len(df_) >= thresh and df_["Close"].notna().sum() >= thresh:
            last10 = df_["Close"].dropna().iloc[-10:]
            if len(last10) >= 10 and last10.nunique() <= 1 and df_["Volume"].iloc[-5:].sum() == 0:
                log.debug("%s source %s has stale/frozen OHLC — ignoring", sym, lbl)
                continue
            candidates.append((df_, lbl))

    if not candidates:
        return None, "—"

    priority = ["Yahoo", "Stooq", "TD", "AV"] if yahoo_ok else ["TD", "Stooq", "AV"]
    candidates.sort(key=lambda x: priority.index(x[1]) if x[1] in priority else 99)
    base_df, base_src = candidates[0]

    # Consensus close: trimmed mean within 5%
    closes = []
    for c_df, _ in candidates:
        try:
            v = float(c_df["Close"].iloc[-1])
            if math.isfinite(v) and v > 0:
                closes.append(v)
        except (IndexError, ValueError, TypeError):
            pass

    if len(closes) >= 2:
        mean_c   = sum(closes) / len(closes)
        filtered = [v for v in closes if abs(v - mean_c) / (mean_c + 1e-9) < 0.05]
        if filtered:
            consensus = sum(filtered) / len(filtered)
            base_df = base_df.copy()
            try:
                base_df.iloc[-1, base_df.columns.get_loc("Close")] = consensus
                base_src += "+" + "+".join(c[1] for c in candidates[1:])
            except (KeyError, IndexError):
                pass

    # Investing.com cross-check
    if inv_price and inv_price > 0:
        try:
            last = float(base_df["Close"].iloc[-1])
            if math.isfinite(last) and abs(last - inv_price) / (last + 1e-9) > 0.03:
                log.warning("Price mismatch %s: base=%.2f INV=%.2f", sym, last, inv_price)
                base_src += "⚠️"
            else:
                base_src += "+INV"
        except (IndexError, ValueError, TypeError):
            pass

    return base_df, base_src


def download_all() -> Dict[str, pd.DataFrame]:
    """Download OHLCV from all enabled sources and return merged results."""
    global _source_labels
    with _source_labels_lock:
        _source_labels = {}

    sym_list = list(SYMBOLS.keys())
    with _data_cfg_lock:
        cfg = dict(DATA_SOURCE_CFG)

    yahoo_by_sym: Dict[str, pd.DataFrame] = {}
    stooq_by_sym: Dict[str, pd.DataFrame] = {}
    inv_prices: Dict[str, float] = {}
    td_by_sym: Dict[str, pd.DataFrame] = {}

    def _do_yahoo():
        nonlocal yahoo_by_sym
        if cfg.get("use_yahoo"):
            yfin_syms = list(SYMBOLS.values())
            if K.EGX30_SYMBOL not in yfin_syms:
                yfin_syms.append(K.EGX30_SYMBOL)
            log.warning("Yahoo Finance: downloading %d symbols...", len(yfin_syms))
            raw = _fetch_yahoo(yfin_syms)
            yahoo_by_sym = {k.replace(".CA", ""): v for k, v in raw.items()}

    def _do_stooq():
        nonlocal stooq_by_sym
        if cfg.get("use_stooq"):
            log.warning("Stooq: downloading...")
            stooq_by_sym = _fetch_stooq(sym_list)

    def _do_investing():
        nonlocal inv_prices
        if cfg.get("use_investing"):
            log.warning("Investing.com: cross-checking prices...")
            inv_prices = _fetch_investing(sym_list)

    def _do_td():
        nonlocal td_by_sym
        td_key = str(cfg.get("twelve_data_key", "")).strip()
        if cfg.get("use_twelve_data") and td_key:
            log.warning("TwelveData: downloading %d symbols...", len(sym_list))
            td_by_sym = _fetch_twelve_data(sym_list, td_key)

    av_by_sym: Dict[str, pd.DataFrame] = {}
    _av_lock = threading.Lock()  # always created; guards av_by_sym writes from _av_bg
    av_thread: Optional[threading.Thread] = None
    av_key = str(cfg.get("alpha_vantage_key", "")).strip()
    if cfg["use_alpha_vantage"] and av_key:
        def _av_bg():
            for s in sym_list[:5]:
                df = _fetch_av_single(s, av_key)
                if df is not None:
                    with _av_lock:   # FIX: guard dict writes from background thread
                        av_by_sym[s] = df
                time.sleep(12)
        av_thread = threading.Thread(target=_av_bg, daemon=True)
        av_thread.start()

    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=4) as executor:
        f1 = executor.submit(_do_yahoo)
        f2 = executor.submit(_do_stooq)
        f3 = executor.submit(_do_investing)
        f4 = executor.submit(_do_td)
        f1.result(); f2.result(); f3.result(); f4.result()

    if av_thread is not None and av_thread.is_alive():
        av_thread.join(timeout=5)

    merged: Dict[str, pd.DataFrame] = {}
    local_labels: Dict[str, str]    = {}

    for sym in sym_list:
        df_y  = yahoo_by_sym.get(sym)
        df_s  = stooq_by_sym.get(sym)
        with _av_lock:           # FIX: safely read av_by_sym
            df_a = av_by_sym.get(sym)
        df_t  = td_by_sym.get(sym)
        inv_p = inv_prices.get(sym)

        df_final, label = _merge_ohlcv(sym, df_y, df_s, df_a, inv_p, td_df=df_t)
        if df_final is not None:
            # Ensure Volume column exists
            if "Volume" not in df_final.columns:
                df_final = df_final.copy()
                df_final["Volume"] = 0.0
            merged[SYMBOLS[sym]] = df_final
            local_labels[sym]    = label

    # Add EGX30 Proxy to merged results if available from Yahoo
    egx_proxy_sym = K.EGX30_SYMBOL.replace(".CA", "") # It shouldn't have .CA, but just in case
    if egx_proxy_sym in yahoo_by_sym:
        df_proxy = yahoo_by_sym[egx_proxy_sym]
        if df_proxy is not None and len(df_proxy) >= K.EGX30_HEALTH_BARS:
            if "Volume" not in df_proxy.columns:
                df_proxy = df_proxy.copy()
                df_proxy["Volume"] = 0.0
            merged[K.EGX30_SYMBOL] = df_proxy
            local_labels["EGX30"] = "Yahoo"

    with _source_labels_lock:
        _source_labels = local_labels

    log.warning(
        "Merged: %d symbols | Y:%d S:%d AV:%d INV:%d TD:%d",
        len(merged), len(yahoo_by_sym), len(stooq_by_sym),
        len(av_by_sym), len(inv_prices), len(td_by_sym),
    )
    return merged


__all__ = [
    "_merge_ohlcv",
    "download_all",
    "_source_labels",
    "_source_labels_lock",
]
