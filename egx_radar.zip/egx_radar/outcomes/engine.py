"""Trade outcome engine: logging, history, and resolution (Layer 9)."""

import json
import logging
import math
import os
from datetime import datetime, date
from typing import Dict, List, Optional, Tuple
import pathlib

import pandas as pd

from egx_radar.config.settings import K, SYMBOLS
from egx_radar.state.app_state import STATE
from egx_radar.core.risk import compute_dynamic_stop
from egx_radar.core.indicators import pct_change_safe

log = logging.getLogger(__name__)

_LOG_DIR = pathlib.Path(K.OUTCOME_LOG_FILE).parent
_LOG_DIR.mkdir(parents=True, exist_ok=True)
import threading
_io_lock = threading.Lock()


def _atomic_json_write(filepath: str, data: object) -> None:
    """Write JSON atomically: temp → os.replace()."""
    import tempfile

    dirpath = os.path.dirname(os.path.abspath(filepath)) or "."
    fd, tmp = tempfile.mkstemp(dir=dirpath, suffix=".tmp", prefix=".egx_")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str)
        os.replace(tmp, filepath)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def oe_load_log() -> List[dict]:
    if not os.path.exists(K.OUTCOME_LOG_FILE):
        return []
    try:
        with open(K.OUTCOME_LOG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        log.warning("oe_load_log: %s", e)
        return []


def oe_save_log(trades: List[dict]) -> None:
    with _io_lock:
        try:
            _atomic_json_write(K.OUTCOME_LOG_FILE, trades)
        except OSError as e:
            log.error("oe_save_log: %s", e)


def oe_load_history() -> List[dict]:
    if not os.path.exists(K.OUTCOME_HISTORY_FILE):
        return []
    try:
        with open(K.OUTCOME_HISTORY_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        log.warning("oe_load_history: %s", e)
        return []


def oe_save_history_batch(new_trades: List[dict]) -> None:
    if not new_trades:
        return
    with _io_lock:
        history = oe_load_history()
        history.extend(new_trades)
        try:
            _atomic_json_write(K.OUTCOME_HISTORY_FILE, history)
        except OSError as e:
            log.error("oe_save_history_batch: %s", e)


def _normalise_df_index(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    try:
        if hasattr(df.index, "tz") and df.index.tz is not None:
            df.index = df.index.tz_convert(None)
    except Exception as e:
        try:
            df.index = pd.to_datetime(df.index).tz_localize(None)
        except Exception as e2:
            log.warning("oe_normalise_df_index failed: %s", e2)
    return df


def oe_resolve_trade(trade: dict, df: Optional[pd.DataFrame]) -> Optional[dict]:
    """Resolve a trade against forward price data. Returns resolved dict or None if still open."""
    if df is None or df.empty:
        return None
    entry  = trade.get("entry", 0.0)
    stop   = trade.get("stop", 0.0)
    target = trade.get("target", 0.0)
    if entry <= 0:
        return None

    try:
        df = _normalise_df_index(df)
    except Exception as e:
        log.warning("oe_resolve_trade normalise error: %s", e)
        return None

    # Stale trade: beyond scaled lookforward
    try:
        trade_date_str = trade.get("date", "")
        if not trade_date_str:
            return None
        trade_date = datetime.strptime(trade_date_str[:10], "%Y-%m-%d")
        age = (datetime.now() - trade_date).days
        if age > K.OUTCOME_LOOKFORWARD_DAYS * K.OUTCOME_STALE_MULTIPLIER:
            try:
                last_close = float(df["Close"].iloc[-1])
            except (IndexError, ValueError):
                last_close = entry
            resolved = dict(trade)
            resolved.update({
                "status": "TIMEOUT",
                "exit_price": round(last_close, 3),
                "days_held": age, "mfe_pct": 0.0, "mae_pct": 0.0,
                "pnl_pct": round(pct_change_safe(last_close, entry), 2),
                "resolved_date": datetime.now().strftime("%Y-%m-%d"),
            })
            return resolved
    except (ValueError, TypeError):
        pass

    try:
        entry_dt  = pd.Timestamp(trade.get("date", ""))
        positions = [i for i, d in enumerate(df.index) if d >= entry_dt]
        if not positions:
            return None
        start = positions[0]
    except (ValueError, TypeError, KeyError) as e:
        log.warning("oe_resolve_trade date parse error for %s: %s", trade.get("sym"), e)
        return None

    window = df.iloc[start:start + K.OUTCOME_LOOKFORWARD_DAYS + 1]
    if len(window) < K.OUTCOME_MIN_BARS_NEEDED:
        return None

    highs  = window["High"].values
    lows   = window["Low"].values
    closes = window["Close"].values
    
    # Needs a 5-bar momentum lookback from the start. We can use the main df for this.
    try:
        start_idx_in_df = df.index.get_loc(window.index[0])
    except KeyError as e:
        log.warning("oe_resolve_trade index missing: %s", e)
        start_idx_in_df = 5  # fallback
        
    outcome = "OPEN"
    exit_bar = len(window) - 1
    mfe = mae = 0.0
    
    # Action type
    is_short = trade.get("action", "").lower() == "sell" or trade.get("tag", "").lower() == "sell"
    current_stop = stop
    current_target = target

    for i, (h, l, c) in enumerate(zip(highs, lows, closes)):
        mfe = max(mfe, pct_change_safe(h, entry))
        mae = max(mae, -pct_change_safe(l, entry))
        
        # Calculate trailing metrics
        df_idx = start_idx_in_df + i
        if df_idx >= 5:
            past_c = df["Close"].iloc[df_idx - 5]
            momentum = pct_change_safe(c, past_c)
        else:
            momentum = 0.0
            
        # Simplified regime flag for trailing: ADX > 25 and close > EMA50 (approximate MOMENTUM)
        # We don't have full ADX here nicely in arrays, so we use momentum proxy
        pseudo_regime = "MOMENTUM" if momentum > 2.5 else "NEUTRAL"
        
        current_stop, current_target, _ = compute_dynamic_stop(
            current_price=c,
            entry=entry,
            current_stop=current_stop,
            current_target=current_target,
            momentum=momentum,
            regime=pseudo_regime,
            is_short=is_short
        )
        
        if is_short:
            if h >= current_stop:
                outcome, exit_bar = "LOSS", i; break
            if l <= current_target:
                outcome, exit_bar = "WIN", i; break
        else:
            if l <= current_stop:
                outcome, exit_bar = "LOSS", i; break
            if h >= current_target:
                outcome, exit_bar = "WIN", i;  break

    if outcome == "OPEN" and len(window) >= K.OUTCOME_LOOKFORWARD_DAYS:
        outcome, exit_bar = "TIMEOUT", len(window) - 1

    if outcome == "OPEN":
        return None

    exit_price = closes[min(exit_bar, len(closes) - 1)]
    resolved   = dict(trade)
    resolved.update({
        "status":     outcome,
        "exit_price": round(float(exit_price), 3),
        "days_held":  exit_bar + 1,
        "mfe_pct":    round(mfe, 2),
        "mae_pct":    round(mae, 2),
        "pnl_pct":    round(pct_change_safe(float(exit_price), entry), 2),
        "resolved_date": datetime.now().strftime("%Y-%m-%d"),
    })

    # Feed breakout result back to MomentumGuard for fatigue tracking
    setup = trade.get("setup_type", "")
    if "breakout" in setup.lower() or trade.get("action", "").lower() in ("buy", "ultra"):
        followed_through = outcome == "WIN"
        try:
            entry_date = date.fromisoformat(trade.get("date", "")[:10])
            if hasattr(STATE, "momentum_guard") and STATE.momentum_guard:
                STATE.momentum_guard.record_breakout_result(
                    symbol=trade.get("sym", ""),
                    followed_through=followed_through,
                    trade_date=entry_date,
                )
        except Exception as e:
            log.warning("[engine] breakout feedback failed: %s", e)

    return resolved


def oe_record_signal(
    sym: str, sector: str, entry: float, stop: float, target: float,
    atr: float, smart_rank: float, anticipation: float, action: str,
    existing_trades: Optional[List[dict]] = None,
    tag: str = "",
) -> None:
    today_str = datetime.now().strftime("%Y-%m-%d")
    trades    = existing_trades if existing_trades is not None else oe_load_log()
    for t in trades:
        if t.get("sym") == sym and t.get("date", "")[:10] == today_str:
            return
    trades.append({
        "sym": sym, "sector": sector, "date": today_str,
        "entry": round(entry, 3), "stop": round(stop, 3), "target": round(target, 3),
        "atr": round(atr, 3) if (atr is not None and math.isfinite(atr)) else 0.0,
        "smart_rank": round(smart_rank, 2) if (smart_rank is not None and math.isfinite(smart_rank)) else 0.0,
        "anticipation": round(anticipation, 2) if (anticipation is not None and math.isfinite(anticipation)) else 0.0,
        "action": action, "status": "OPEN",
        # Fields for alpha_monitor (populated here or at resolution)
        "setup_type": tag or action,  # signal tag (ultra/early/buy/watch)
        "exit_price": None,           # set by oe_resolve_trade()
        "result_pct": None,           # set by oe_resolve_trade()
        "stop_hit": None,             # set by oe_resolve_trade() → True if status=="LOSS"
    })
    oe_save_log(trades)


def oe_process_open_trades(all_data: Dict[str, pd.DataFrame]) -> Tuple[List[dict], int, int]:
    """Resolve open trades. Returns (remaining, wins, losses)."""
    trades = oe_load_log()
    if not trades:
        return [], 0, 0

    remaining: List[dict] = []
    batch:     List[dict] = []
    wins = losses = 0

    for trade in trades:
        sym   = trade.get("sym", "")
        yahoo = SYMBOLS.get(sym)
        df    = all_data.get(yahoo) if yahoo else None
        resolved = oe_resolve_trade(trade, df)
        if resolved is None:
            remaining.append(trade)
            continue
        batch.append(resolved)
        outcome = resolved["status"]
        rank    = trade.get("smart_rank", 0.0)
        ant     = trade.get("anticipation", 0.0)
        sec     = trade.get("sector", "")
        t_tag   = trade.get("action", "").lower()   # FIX-5: pass sector+tag
        if outcome == "WIN":
            wins += 1
            STATE.record_win(rank, ant, sector=sec, tag=t_tag)
        elif outcome in ("LOSS", "TIMEOUT"):
            if outcome == "LOSS":
                losses += 1
            STATE.record_loss(rank, ant, sector=sec, tag=t_tag)

    oe_save_history_batch(batch)
    oe_save_log(remaining)
    return remaining, wins, losses


def oe_save_rejections(rejections: List[Dict[str, str]]) -> None:
    """Save a list of rejected symbols and reasons to a CSV file."""
    if not rejections:
        return
        
    filepath = _LOG_DIR / "rejected_symbols.csv"
    try:
        df = pd.DataFrame(rejections)
        df["date"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        # Append if exists and today, else overwrite
        mode = 'a' if os.path.exists(filepath) else 'w'
        header = not os.path.exists(filepath)
        df.to_csv(filepath, mode=mode, header=header, index=False, encoding="utf-8")
    except Exception as e:
        log.error("Failed to save rejections: %s", e)


__all__ = [
    "oe_load_log",
    "oe_save_log",
    "oe_load_history",
    "oe_save_history_batch",
    "_normalise_df_index",
    "oe_resolve_trade",
    "oe_record_signal",
    "oe_process_open_trades",
    "oe_save_rejections",
]
