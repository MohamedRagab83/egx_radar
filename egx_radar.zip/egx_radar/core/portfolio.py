"""Portfolio guard: sector and ATR exposure limits (Layer 7)."""

import logging
from typing import Dict, List, NamedTuple, Tuple

from egx_radar.config.settings import (
    K,
    SECTORS,
    get_account_size,
    get_max_per_sector,
    get_atr_exposure,
)

log = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════
# LAYER 7: PORTFOLIO GUARD — Pure function, non-mutating, idempotent
# ═══════════════════════════════════════════════════════════════════════════


class GuardedResult(NamedTuple):
    """Immutable wrapper for a result record with guard annotation."""
    result: dict
    guard_reason: str
    is_blocked: bool


def compute_portfolio_guard(
    results: List[dict],
    account_size: float = None,
    open_trades: List[dict] = None,
) -> Tuple[List[GuardedResult], Dict[str, int], float, List[str]]:
    """
    FIX-G: Pure function.  Does NOT mutate input `results`.
    Uses live account_size from DATA_SOURCE_CFG so UI changes apply immediately.
    """
    if account_size is None:
        account_size = get_account_size()
    max_per_sector = get_max_per_sector()
    atr_exposure   = get_atr_exposure()

    active_tags    = {"buy", "ultra", "early"}
    sector_counts: Dict[str, int] = {s: 0 for s in SECTORS}
    cumulative     = 0.0
    
    # Feature 5: Advanced Portfolio Guard
    # Pre-fill exposure with currently active trades
    if open_trades:
        for t in open_trades:
            sec = t.get("sector")
            if sec in sector_counts:
                sector_counts[sec] += 1
            # Assuming size and atr are present or can be calculated (using standard risk)
            # If not present, we will estimate based on standard 4% risk
            t_atr = t.get("atr", 0.0)
            if t_atr > 0 and t.get("size"):
                cumulative += (t_atr * t.get("size", 0))
            else:
                # Estimate standard risk deduction if missing from log
                cumulative += account_size * atr_exposure

    max_exposure   = account_size * atr_exposure
    guarded:       List[GuardedResult] = []
    blocked_syms:  List[str]           = []

    for r in results:
        if r["tag"] not in active_tags:
            guarded.append(GuardedResult(r, "", False))
            continue

        sector  = r["sector"]
        atr     = r.get("atr") or 0.0
        size    = (r.get("plan") or {}).get("size", 0)
        contrib = atr * size

        if sector_counts.get(sector, 0) >= max_per_sector:
            reason = (
                f"Sector cap: {sector} already has "
                f"{sector_counts[sector]} signal(s) (max {max_per_sector})"
            )
            blocked_syms.append(r["sym"])
            guarded.append(GuardedResult(r, reason, True))
            continue

        if cumulative + contrib > max_exposure:
            reason = (
                f"ATR cap: +{contrib:.0f} EGP would bring total to "
                f"{(cumulative+contrib):.0f} EGP "
                f"({(cumulative+contrib)/max(1e-9, account_size)*100:.1f}% of account, "
                f"max {atr_exposure*100:.0f}%)"
            )
            blocked_syms.append(r["sym"])
            guarded.append(GuardedResult(r, reason, True))
            continue

        sector_counts[sector] = sector_counts.get(sector, 0) + 1
        cumulative += contrib
        guarded.append(GuardedResult(r, "", False))

    return guarded, sector_counts, cumulative, blocked_syms

