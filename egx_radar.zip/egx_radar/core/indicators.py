"""Technical indicator functions for EGX Radar."""

import pandas as pd
from typing import Optional, Tuple
from config.settings import K


def safe_clamp(val: float, lo: float, hi: float) -> float:
    """Clamp value between lo and hi."""
    return max(lo, min(hi, val))


def last_val(s: pd.Series) -> float:
    """Get the last value from a series."""
    s = s.dropna()
    return float(s.iloc[-1]) if not s.empty else 0.0


def compute_atr(df: pd.DataFrame, length: int = 14) -> Optional[float]:
    """Compute ATR (Average True Range)."""
    if length is None:
        length = K.ATR_LENGTH
    if len(df) < 2:
        return None
    try:
        h = df["High"].reset_index(drop=True)
        l = df["Low"].reset_index(drop=True)
        c = df["Close"].reset_index(drop=True)
        tr = pd.concat([
            h - l,
            (h - c.shift()).abs(),
            (l - c.shift()).abs(),
        ], axis=1).max(axis=1)
        atr = float(tr.tail(length).mean())
        return atr if (atr is not None and atr > 0) else None
    except Exception:
        return None


def compute_atr_risk(df: pd.DataFrame, price: float) -> Tuple[str, float]:
    """Compute ATR percentile-based risk scoring."""
    if price <= 0 or len(df) < K.ATR_LENGTH + 5:
        return "—", 0.0
    try:
        h = df["High"].reset_index(drop=True)
        l = df["Low"].reset_index(drop=True)
        c = df["Close"].reset_index(drop=True)
        tr = pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
        atr_series = tr.rolling(K.ATR_LENGTH).mean().dropna()
        if len(atr_series) < 5:
            return "—", 0.0
        hist = atr_series.iloc[-K.ATR_HIST_WINDOW:].values
        current = hist[-1]
        pct = float((hist <= current).mean()) * 100.0
        if pct >= K.ATR_PCT_HIGH:
            return "⚠️ HIGH", pct
        if pct >= K.ATR_PCT_MED:
            return "🟡 MED", pct
        return "🟢 LOW", pct
    except Exception:
        return "—", 0.0


def compute_vwap_dist(df: pd.DataFrame, price: float) -> float:
    """VWAP distance = (price - vwap) / price. Clamped to (-0.5, 0.5)."""
    try:
        close = df["Close"].dropna()
        vol = df["Volume"].dropna()
        if len(close) < 10 or vol.sum() <= 0:
            return 0.0
        n = min(len(close), len(vol), K.VWAP_ROLL_WINDOW)
        close, vol = close.iloc[-n:], vol.iloc[-n:]
        cum_vol = vol.cumsum()
        if cum_vol.iloc[-1] <= 0:
            return 0.0
        vwap = float((close * vol).cumsum().iloc[-1] / cum_vol.iloc[-1])
        return safe_clamp((price - vwap) / price, -0.5, 0.5) if vwap > 0 else 0.0
    except Exception:
        return 0.0


def compute_vol_zscore(df: pd.DataFrame, window: int = None) -> float:
    """Compute volume Z-score with symmetric clamp."""
    if window is None:
        window = K.VOL_ROLL_WINDOW
    try:
        vol = df["Volume"].dropna()
        if vol.sum() <= 0 or len(vol) < window + 2:
            return 0.0
        mu = float(vol.rolling(window).mean().iloc[-1])
        sig = float(vol.rolling(window).std().iloc[-1])
        if sig <= 0 or not (sig is not None and sig > 0):
            return 0.0
        return safe_clamp((float(vol.iloc[-1]) - mu) / sig, K.VOL_ZSCORE_LO, K.VOL_ZSCORE_HI)
    except Exception:
        return 0.0


def detect_ema_cross(close: pd.Series) -> str:
    """Detect EMA10/EMA50 crossover."""
    if len(close) < 55:
        return ""
    ema10 = close.ewm(span=10, adjust=False).mean()
    ema50 = close.ewm(span=50, adjust=False).mean()
    for i in range(-7, 0):
        prev = ema10.iloc[i-1] > ema50.iloc[i-1]
        curr = ema10.iloc[i] > ema50.iloc[i]
        if not prev and curr:
            return "BULL_CROSS"
        if prev and not curr:
            return "BEAR_CROSS"
    return ""


def detect_vol_divergence(close: pd.Series, volume: pd.Series, lookback: int = 5) -> str:
    """Detect volume/price divergence patterns."""
    if len(close) < lookback + 2:
        return ""
    price_chg = float(close.iloc[-1]) - float(close.iloc[-lookback])
    vol_ma = volume.rolling(3).mean()
    if len(vol_ma.dropna()) < lookback:
        return ""
    vol_trend = float(vol_ma.iloc[-1]) - float(vol_ma.iloc[-lookback])
    if price_chg > 0 and vol_trend > 0:
        return "🟢BULL_CONF"
    if price_chg > 0 and vol_trend < 0:
        return "🔀BEAR_DIV"
    if price_chg < 0 and vol_trend < 0:
        return "🔵BASE"
    if price_chg < 0 and vol_trend > 0:
        return "⚠️CLIMAX_SELL"
    return ""


def compute_ud_ratio(close: pd.Series, period: int = 14) -> float:
    """Compute Up/Down ratio for RSI calculation."""
    delta = close.diff()
    gain = delta.where(delta > 0, 0.0)
    loss = (-delta).where(delta < 0, 0.0)
    avg_gain = gain.rolling(window=period, min_periods=period).mean()
    avg_loss = loss.rolling(window=period, min_periods=period).mean()
    if avg_loss.iloc[-1] == 0:
        return 100.0
    rs = avg_gain.iloc[-1] / avg_loss.iloc[-1]
    return 100.0 - (100.0 / (1.0 + rs))


def detect_vcp(df: pd.DataFrame, lookback: int = 20) -> bool:
    """Detect Volatility Contraction Pattern (VCP)."""
    try:
        if len(df) < lookback:
            return False
        close = df["Close"]
        high = df["High"]
        low = df["Low"]
        
        # Calculate recent volatility
        recent_vol = close.pct_change().rolling(lookback).std()
        
        # Find contraction (lower volatility than average)
        avg_vol = recent_vol.mean()
        current_vol = recent_vol.iloc[-1]
        
        if current_vol < avg_vol * 0.7:  # 30% contraction
            return True
        return False
    except Exception:
        return False


def compute_cmf(df: pd.DataFrame, period: int = None) -> float:
    """Chaikin Money Flow indicator."""
    import numpy as np
    if period is None:
        period = K.CMF_PERIOD
    
    if df is None or len(df) < period:
        return 0.0
    
    try:
        high  = df["High"].values[-period:]
        low   = df["Low"].values[-period:]
        close = df["Close"].values[-period:]
        volume = df["Volume"].values[-period:]
        
        denom = high - low
        denom = np.where(denom == 0, 1e-9, denom)
        
        mfm = ((close - low) - (high - close)) / denom
        mfv = mfm * volume
        
        cmf = mfv.sum() / volume.sum() if volume.sum() > 0 else 0.0
        return round(float(cmf), 4)
    except Exception:
        return 0.0


def sharpe_from_trades(trades: list, risk_free_rate: float = 0.0) -> float:
    """Calculate Sharpe ratio from trade returns."""
    import numpy as np
    try:
        # Handle both list of dicts AND list of floats
        if not trades:
            return 0.0
        
        if isinstance(trades[0], dict):
            returns = [t.get("pnl_pct", 0) for t in trades]
        else:
            returns = [float(t) for t in trades]
        
        arr = np.array(returns) / 100
        if arr.std() == 0:
            return 0.0
        return round(float(arr.mean() / arr.std() * np.sqrt(250)), 2)
    except Exception:
        return 0.0


def pct_change_safe(current: float, previous: float) -> float:
    """Calculate percentage change safely, avoiding division by zero."""
    if previous is None or previous == 0:
        return 0.0
    return ((current - previous) / previous) * 100


# ── ATR shrinking check (the function that was causing the bug) ────────────────
def is_atr_shrinking(df: pd.DataFrame, length: int = 14, bars: int = 5) -> bool:
    """Check if ATR has been shrinking for the last `bars`."""
    length = K.ATR_LENGTH  # read from config at call time
    try:
        if len(df) < length + bars:
            return False
        h = df["High"].reset_index(drop=True)
        l = df["Low"].reset_index(drop=True)
        c = df["Close"].reset_index(drop=True)
        tr = pd.concat([
            h - l,
            (h - c.shift()).abs(),
            (l - c.shift()).abs(),
        ], axis=1).max(axis=1)
        atr_series = tr.rolling(length).mean().dropna()
        if len(atr_series) < bars:
            return False
        
        # checks if atr[i] - atr[i-1] < 0 for the last `bars-1` diffs
        return (atr_series.tail(bars).diff().dropna() < 0).all()

    except Exception:
        return False

